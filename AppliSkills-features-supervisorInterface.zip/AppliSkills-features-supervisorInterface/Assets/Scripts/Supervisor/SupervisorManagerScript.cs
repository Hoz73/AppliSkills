﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SupervisorManagerScript : MonoBehaviour
{
    //Navigation panels
    [Header("NAVIGATION PANELS")]
    [SerializeField] private GameObject supervisorPanel;

    //Browse panels
    [Header("BROWSE PANELS")]
    [Space(30)]
    [SerializeField] private GameObject skillGroupPanel;
    [SerializeField] private GameObject userGroupPanel;
    [SerializeField] private TMP_InputField nameSkillGroupInputField;
    [SerializeField] private TMP_InputField nameUserGroupInputField;

    [Header("SEARCH RESULT PANELS")]
    [Space(30)]
    [SerializeField] private GameObject skillGroupResultPanel;
    [SerializeField] private GameObject userGroupResultPanel;

    [Header("PREFABS")]
    [Space(30)]
    [SerializeField] private GameObject button;

    //instances
    [Header("INSTANCES")]
    [Space(30)]
    //private DataBaseManager dataBase;
    [SerializeField] private GameObject supervisorPrefab;

    //The list of supervisors
    [Header("LISTS TO INSTANTIATE THE OBJECTS IN")]
    [Space(30)]
    [SerializeField] private GameObject listOfSupervisors;



    public void BrowseBySkillGroupButton()
    {
        supervisorPanel.SetActive(false);
        skillGroupPanel.SetActive(true);

    }

    public void BrowseByUserGroupButton()
    {
        supervisorPanel.SetActive(false);
        userGroupPanel.SetActive(true);

    }

    public void Disconnect()
    {
        DataBaseManager.LogOut();
        SceneManager.LoadScene("LogIn");
    }

    public void ReturnToSupervisorPanel()
    {
        userGroupPanel.SetActive(false);
        skillGroupPanel.SetActive(false);

        supervisorPanel.SetActive(true);
    }

    public void SkillPanelActivate()
    {

        //for (var i = 0; i < skillGroupResultPanel.transform.childCount; i++)
        //{
        //    if (skillGroupResultPanel.transform.GetChild(i).GetComponent<Image>().color == Color.red)
        //    {
        //        var text = skillGroupResultPanel.transform.GetChild(i).transform.GetChild(1).GetComponent<Text>().text;
        //        var skillGroupName = text.Split(' ')[0];
        //        DataBaseManager.SkillGroupNameToEdit = skillGroupName;
        //    }
        //}
        //Debug.Log(DataBaseManager.SkillGroupNameToEdit);
        //skillPanel.SetActive(true);
        //skillGroupPanel.SetActive(false);
    }

    public void SwitchState()
    {
        //for (var i = 0; i < skillResultPanel.transform.childCount; i++)
        //{
        //    if (skillResultPanel.transform.GetChild(i).GetComponent<Image>().color == Color.red)
        //    {
        //        var text = skillResultPanel.transform.GetChild(i).transform.GetChild(1).GetComponent<Text>().text;
        //        string[] afterSplit = text.Split(' ');
        //        string state = afterSplit[afterSplit.Length - 1];

        //        string skillName = null;
        //        for (int j = 0; j < afterSplit.Length - 1; j++)
        //        {
        //            skillName += afterSplit[j];
        //            if (j < afterSplit.Length - 2) skillName += ' ';
        //        }

        //        StartCoroutine(UpdateState(skillName, state));
        //        ClearResultPanels();
        //    }
        //}
    }


}
